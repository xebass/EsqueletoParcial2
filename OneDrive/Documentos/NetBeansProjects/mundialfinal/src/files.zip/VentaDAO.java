package dao;

import conexion.CreateConection;
import modelo.Cliente;
import modelo.Partido;
import modelo.Ticket;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VentaDAO {

    private final CreateConection connFactory = new CreateConection();

    // ── Partidos disponibles ─────────────────────────────────────────────
    public List<Partido> obtenerPartidos() {
        List<Partido> lista = new ArrayList<>();
        String sql = "SELECT id, equipo_local, equipo_visitante, fecha, estadio, fase, estado " +
                     "FROM partido WHERE estado = 'DISPONIBLE' ORDER BY fecha";
        try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Partido p = new Partido(
                        rs.getInt("id"),
                        rs.getString("equipo_local"),
                        rs.getString("equipo_visitante"),
                        rs.getTimestamp("fecha"),
                        rs.getString("estadio"),
                        rs.getString("fase"),
                        rs.getString("estado")
                );
                lista.add(p);
            }
        } catch (SQLException ex) {
            System.out.println("Error obtenerPartidos: " + ex.getMessage());
        }
        return lista;
    }

    // ── Tickets disponibles de un partido ────────────────────────────────
    public List<Ticket> obtenerTicketsDisponibles(int partidoId) {
        List<Ticket> lista = new ArrayList<>();
        String sql = "SELECT id, partido_id, numero_asiento, seccion, precio, estado " +
                     "FROM ticket WHERE partido_id = ? AND estado = 'DISPONIBLE' " +
                     "ORDER BY seccion, numero_asiento";
        try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, partidoId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Ticket t = new Ticket(
                        rs.getInt("id"),
                        rs.getInt("partido_id"),
                        rs.getString("numero_asiento"),
                        rs.getString("seccion"),
                        rs.getDouble("precio"),
                        rs.getString("estado")
                );
                lista.add(t);
            }
            rs.close();
        } catch (SQLException ex) {
            System.out.println("Error obtenerTickets: " + ex.getMessage());
        }
        return lista;
    }

    // ── Clientes ─────────────────────────────────────────────────────────
    public List<Cliente> obtenerClientes() {
        List<Cliente> lista = new ArrayList<>();
        String sql = "SELECT id, nombre, apellido, telefono, email, direccion " +
                     "FROM cliente ORDER BY apellido, nombre";
        try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Cliente cl = new Cliente(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("telefono"),
                        rs.getString("email"),
                        rs.getString("direccion")
                );
                lista.add(cl);
            }
        } catch (SQLException ex) {
            System.out.println("Error obtenerClientes: " + ex.getMessage());
        }
        return lista;
    }

    public boolean guardarCliente(Cliente cl) {
        String sql = "INSERT INTO cliente (nombre, apellido, telefono, email, direccion) " +
                     "VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = connFactory.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, cl.getNombre());
            ps.setString(2, cl.getApellido());
            ps.setString(3, cl.getTelefono());
            ps.setString(4, cl.getEmail());
            ps.setString(5, cl.getDireccion());
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) cl.setId(keys.getInt(1));
            return true;
        } catch (SQLException ex) {
            System.out.println("Error guardarCliente: " + ex.getMessage());
        }
        return false;
    }

    // ── Guardar venta completa (transacción) ─────────────────────────────
    public boolean guardarVenta(Cliente cliente, List<Ticket> tickets,
                                int usuarioId, double total) {
        Connection conn = null;
        try {
            conn = connFactory.getConnection();
            conn.setAutoCommit(false);

            // 1. insertar en venta
            int ventaId;
            String sqlVenta = "INSERT INTO venta (fecha, cliente_id, usuario_id, total) " +
                              "VALUES (NOW(), ?, ?, ?) RETURNING id";
            try (PreparedStatement ps = conn.prepareStatement(sqlVenta)) {
                ps.setInt(1, cliente.getId());
                ps.setInt(2, usuarioId);
                ps.setDouble(3, total);
                ResultSet rs = ps.executeQuery();
                rs.next();
                ventaId = rs.getInt(1);
            }

            // 2. insertar detalle y marcar tickets como VENDIDO
            String sqlDetalle = "INSERT INTO detalle_venta (venta_id, ticket_id, precio, iva) VALUES (?, ?, ?, ?)";
            String sqlTicket  = "UPDATE ticket SET estado = 'VENDIDO' WHERE id = ?";
            double iva = (total / tickets.size()) * 0.12; // iva proporcional por ticket

            try (PreparedStatement psDet = conn.prepareStatement(sqlDetalle);
                 PreparedStatement psTck = conn.prepareStatement(sqlTicket)) {
                for (Ticket t : tickets) {
                    psDet.setInt(1, ventaId);
                    psDet.setInt(2, t.getId());
                    psDet.setDouble(3, t.getPrecio());
                    psDet.setDouble(4, iva);
                    psDet.addBatch();

                    psTck.setInt(1, t.getId());
                    psTck.addBatch();
                }
                psDet.executeBatch();
                psTck.executeBatch();
            }

            conn.commit();
            return true;

        } catch (SQLException ex) {
            System.out.println("Error guardarVenta: " + ex.getMessage());
            try { if (conn != null) conn.rollback(); } catch (SQLException ignored) {}
        } finally {
            try { if (conn != null) conn.close(); } catch (SQLException ignored) {}
        }
        return false;
    }
}
